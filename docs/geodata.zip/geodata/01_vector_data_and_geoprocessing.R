# Install sf

# Import municipalities.



# Plot municpalities with sf. The filling color must be blue
# and borders must be thick.

# Plot municipalities with mapsf. The filling color must be lightgreen
# and borders must be white and thin.



# Add the restaurants to the municpalities map.

# How many municipalities are there?

# Which commune has the largest population?



# Import the com.csv file.

# Join this dataset to the municipality layer.

# Extract municipalities with more than 500 active workers
# and whose share of active workers in the total population is greater than 30%.

# Plot a map with all municipalities in gray and selected municipalities in red.



# Import the layers of municipalities and restaurants.

# Perform a spatial join to find the name and identifier of the municipality 
# where each restaurant is located.



# Compute the number of restaurants per municipality.

# Which municipalities have more than 10 restaurants
# and fewer than 1000 inhabitants?

# Create a map showing all the municipalities in grey and the municipalities 
# selected above in red.
