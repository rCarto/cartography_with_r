# How to represent the following variables:
# A municipal population
# A median age by region
# A population growth rate
# The administrative status of municipalities
# Life expectancy per country



# Import the com.csv file.

# Join this dataset to the municipality layer.

# Create a map of the working population.
# Which type of map should be used? What choices does this involve?

# Create a map of the share of the working population in the total population.
# Which type of map should be used? What choices does this involve?



# Create a map showing the working population in the industrial sector.

# Add the necessary layout elements.

# Make the map more intelligible, more explicit.

# Export the map in PNG format, 1000 pixels wide.





